# Kobywatel
Pamiętaj ta strona służy do generowania dowodów w celach edukacyjnych lub do wykorzystania w produkcjach filmowych, używanie wygenerowanego dowodu jako oryginału wystawionego przez państwo jest nielegalne 🪪
    PRZED KORZYSTANIEM PRZECZYTAJ REGULAMIN❗❗️❗️
